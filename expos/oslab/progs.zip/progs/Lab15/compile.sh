./spl ../MyLabs/Lab15/timer_interrupt.spl
./spl ../MyLabs/Lab15/write_interrupt_int7.spl
./spl ../MyLabs/Lab15/device_manager_module4.spl
./spl ../MyLabs/Lab15/resource_manager_module0.spl
./spl ../MyLabs/Lab15/boot_module.spl
./spl ../MyLabs/Lab15/scheduler_module5.spl
./spl ../MyLabs/Lab15/os_startup.spl
./spl ../MyLabs/Lab15/int10_module.spl