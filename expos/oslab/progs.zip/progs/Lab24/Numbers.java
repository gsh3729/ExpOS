import java.util.*;

public class Numbers {

    public static void main(String[] args) {
        for(int i = 1; i <= 2047; i++) {
            System.out.println(i);
        }
    }

}